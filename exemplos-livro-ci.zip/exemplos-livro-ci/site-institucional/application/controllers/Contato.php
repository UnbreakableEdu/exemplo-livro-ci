<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Contato extends CI_Controller {
public function FaleConosco()
{
$data['title'] = "LCI | Fale Conosco";
$data['description'] = "Exercício de exemplo do capítulo
5 do livro CodeIgniter";
$this->load->view('fale-conosco',$data);
}
public function TrabalheConosco()
{
$data['title'] = "LCI | Trabalhe Conosco";
$data['description'] = "Exercício de exemplo do capítulo
5 do livro CodeIgniter";
$this->load->view('trabalhe-conosco',$data);
}
}
function __construct(){
    parent::__construct();
    $this->load->library('form_validation');
    $this->load->helper('form');
    }
?>